<head>
    <link rel="stylesheet" href="registration-success.css">
</head>
<?php
    // Retrieve form data securely
    $exmne_fullname = htmlspecialchars($_POST['fullname']);
    $exmne_birthdate = $_POST['birthdate'];
    $exmne_gender = $_POST['gender'];
    $exmne_course = $_POST['role'];  // Ensure this matches the 'name' attribute in your form
    $exmne_email = $_POST['email'];
    $exmne_password = $_POST['password']; // Use password hashing for security

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'cee_db');

    // Check connection
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    } else {
        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO examinee_tbl (exmne_fullname, exmne_birthdate, exmne_gender, exmne_course, exmne_email, exmne_password)
                                VALUES (?, ?, ?, ?, ?, ?)");

        // Bind the parameters
        $stmt->bind_param("ssssss", $exmne_fullname, $exmne_birthdate, $exmne_gender, $exmne_course, $exmne_email, $exmne_password);

        // Execute the statement and handle success or failure
        if ($stmt->execute()) {
            echo "<div class='registration-success'>Account Registration successful</div>";
        } else {
            echo "<div class='registration-failure'>Registration failed: " . $stmt->error . "</div>";
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    }
?>
